import pyautogui
import subprocess
import time
import sys
import os
import requests
import csv
import re
import tkinter as tk
from tkinter import filedialog
import keyboard
import msvcrt 

# Windows Command Prompt-এ কালার সাপোর্ট চালু করার জন্য
os.system("") 

# ==========================================
# COLOR & FORMATTING CODES
# ==========================================
class Color:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    CYAN = '\033[96m'
    BOLD = '\033[1m'
    RESET = '\033[0m'

# ==========================================
# GLOBAL EMERGENCY STOP: ESC KEY
# ==========================================
def emergency_stop():
    print(f"\n\n{Color.RED}{Color.BOLD}==================================================={Color.RESET}")
    print(f"{Color.RED}{Color.BOLD} [!] ESC KEY PRESSED! Emergency Stop Activated.{Color.RESET}")
    print(f"{Color.RED}{Color.BOLD} [*] Closing the program immediately. Goodbye!{Color.RESET}")
    print(f"{Color.RED}{Color.BOLD}==================================================={Color.RESET}")
    os._exit(0) 

keyboard.add_hotkey('esc', emergency_stop)
# ==========================================

def get_single_key(prompt_text, valid_keys):
    print(prompt_text, end='', flush=True)
    while True:
        try:
            key = msvcrt.getch().decode('utf-8').lower()
            if key in valid_keys:
                print(f"{Color.CYAN}{key}{Color.RESET}") 
                return key
        except UnicodeDecodeError:
            pass 

def start_winbox_automation(routers):
    if not routers:
        print(f"\n{Color.RED}[X] No routers to add. Returning to menu...{Color.RESET}")
        time.sleep(1)
        return

    # ==========================================
    # USERNAME & PASSWORD PROMPT
    # ==========================================
    print(f"\n{Color.CYAN}{Color.BOLD}--- Router Login Credentials ---{Color.RESET}")
    print(f"{Color.YELLOW}[*] These credentials will be used for all {len(routers)} routers.{Color.RESET}")
    
    username = input(f"{Color.BOLD}Enter Username (Default 'admin'): {Color.RESET}").strip()
    if not username:
        username = "admin" 
        
    password = input(f"{Color.BOLD}Enter Password: {Color.RESET}").strip()

    print(f"\n{Color.YELLOW}{Color.BOLD}==================================================={Color.RESET}")
    print(f"{Color.YELLOW}{Color.BOLD} [!] SUPERFAST AUTOMATION RUNNING: Do not touch the mouse!{Color.RESET}")
    print(f"{Color.YELLOW}{Color.BOLD} [!] Press 'Esc' anytime to instantly stop and exit.{Color.RESET}")
    print(f"{Color.YELLOW}{Color.BOLD}==================================================={Color.RESET}")

    try:
        print(f"\n{Color.CYAN}[*] Opening Winbox... Please wait 1 second.{Color.RESET}")
        subprocess.Popen("winbox64.exe")
        time.sleep(1) 
    except FileNotFoundError:
        print(f"\n{Color.RED}{Color.BOLD}[X] ERROR: winbox64.exe not found! Please keep it in the same folder.{Color.RESET}")
        time.sleep(2)
        return

    print(f"{Color.CYAN}[*] Starting automation for {len(routers)} routers at MAX SPEED...{Color.RESET}")
    
    # পাইথনের গ্লোবাল টাইপিং স্পিড একদম কমিয়ে দেওয়া হলো
    pyautogui.PAUSE = 0.015 
    
    for data in routers:
        if len(data) < 3: continue
        ip, note, group = data[0].strip(), data[1].strip(), data[2].strip()

        pyautogui.hotkey('ctrl', 'a')
        pyautogui.press('backspace')
        pyautogui.write(ip)

        pyautogui.press('tab')
        pyautogui.write(username)

        pyautogui.press('tab')
        pyautogui.write(password)

        pyautogui.press('tab', presses=3, interval=0.01)
        pyautogui.write(note)

        pyautogui.press('tab')
        pyautogui.write(group)

        pyautogui.press('tab', presses=2, interval=0.01)
        pyautogui.press('enter')
        
        # পরবর্তী এন্ট্রির জন্য উইনবক্সকে জাস্ট একটু সময় দেওয়া
        time.sleep(0.05) 

        pyautogui.keyDown('shift')
        pyautogui.press('tab', presses=8, interval=0.01)
        pyautogui.keyUp('shift')

    print(f"\n{Color.GREEN}{Color.BOLD}[SUCCESS] All routers have been added superfast!{Color.RESET}")

while True:
    print(f"\n{Color.CYAN}{Color.BOLD}==================================================={Color.RESET}")
    print(f"{Color.CYAN}{Color.BOLD}           Mikrotik Winbox Auto Setup (Fast Mode){Color.RESET}")
    print(f"{Color.CYAN}{Color.BOLD}==================================================={Color.RESET}")
    print(f"{Color.RED}{Color.BOLD} [!] Global Shortcut: Press 'Esc' ANYTIME to Exit{Color.RESET}")
    print(f"{Color.CYAN}{Color.BOLD}==================================================={Color.RESET}")
    print("How would you like to add the routers?")
    print("1. Manual Entry (Type IP and Port Number, Note, and Group)")
    print("2. Browse Local File (Select a .txt or .csv file from PC)")
    print("3. From Online Link (Google Spreadsheet Normal Share Link)")
    print(f"{Color.RED}0. Exit Automation{Color.RESET}")
    print(f"{Color.CYAN}{Color.BOLD}==================================================={Color.RESET}")

    choice = get_single_key(f"{Color.BOLD}Enter your choice (1/2/3/0): {Color.RESET}", ['1', '2', '3', '0'])
    routers_list = []

    if choice == '1':
        print(f"\n\n{Color.CYAN}{Color.BOLD}--- Manual Entry Mode ---{Color.RESET}")
        print(f"{Color.CYAN}==================================================={Color.RESET}")
        print(" - IP & Port : e.g., 10.10.10.10:8080")
        print(" - Note      : e.g., Core_Router_1")
        print(" - Group     : e.g., Main_Office")
        print(f"{Color.YELLOW} Rule: Do NOT use commas inside Note or Group names!{Color.RESET}")
        print(f"{Color.CYAN}==================================================={Color.RESET}")
        
        if get_single_key(f"\n{Color.BOLD}[?] Start Manual Entry? Press 'y' to continue or 'n' to go back: {Color.RESET}", ['y', 'n']) == 'y':
            print() 
            while True:
                ip = input("Enter IP and Port Number: ").strip()
                note = input("Enter Note: ").strip()
                group = input("Enter Group: ").strip()
                routers_list.append([ip, note, group])
                if get_single_key(f"{Color.BOLD}Add another router? (y/n): {Color.RESET}", ['y', 'n']) == 'n': break
                print() 
            start_winbox_automation(routers_list)
            break 
        else:
            print(f"\n{Color.CYAN}[*] Returning to Main Menu...{Color.RESET}")
            time.sleep(1)

    elif choice == '2':
        print(f"\n\n{Color.CYAN}{Color.BOLD}--- Local File Mode ---{Color.RESET}")
        print(f"{Color.CYAN}==================================================={Color.RESET}")
        print(" Format : IP_Address_or_IP:Port,Note,Group")
        print(" Example: 10.10.10.10:8080,Core_Router_1,Main_Office")
        print(f"{Color.YELLOW} Rule   : Do NOT use commas inside Note or Group names!{Color.RESET}")
        print(f"{Color.CYAN}==================================================={Color.RESET}")
        
        if get_single_key(f"\n{Color.BOLD}[?] Checked file format? Press 'y' to browse or 'n' to go back: {Color.RESET}", ['y', 'n']) == 'y':
            print(f"\n\n{Color.CYAN}[*] Opening file browser...{Color.RESET}")
            root = tk.Tk(); root.withdraw(); root.attributes('-topmost', True)
            file_path = filedialog.askopenfilename(title="Select File", filetypes=(("Text/CSV", "*.txt;*.csv"), ("All", "*.*")))
            if file_path:
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        for line in f:
                            data = line.strip().split(',')
                            if len(data) >= 3: routers_list.append(data)
                    start_winbox_automation(routers_list)
                    break
                except Exception as e:
                    print(f"\n{Color.RED}{Color.BOLD}[X] ERROR: {e}{Color.RESET}")
                    time.sleep(2)
            else:
                print(f"\n{Color.RED}[X] No file selected!{Color.RESET}")
                time.sleep(1)
        else:
            print(f"\n\n{Color.CYAN}[*] Returning...{Color.RESET}")
            time.sleep(1)

    elif choice == '3':
        print(f"\n\n{Color.CYAN}{Color.BOLD}--- Google Spreadsheet Mode ---{Color.RESET}")
        print(f"{Color.CYAN}==================================================={Color.RESET}")
        print(" - Column A: IP Address or IP:Port (e.g., 10.10.10.10:8080)")
        print(" - Column B: Note (e.g., Core_Router_1)")
        print(" - Column C: Group (e.g., Main_Office)")
        print(f"{Color.YELLOW} Rule: Sheet access must be 'Anyone with the link'.{Color.RESET}")
        print(f"{Color.CYAN}==================================================={Color.RESET}")
        
        sheet_url = input(f"\n{Color.BOLD}Paste Link (or 'n' to go back): {Color.RESET}").strip()
        if sheet_url.lower() == 'n': continue
            
        match = re.search(r'/d/([a-zA-Z0-9-_]+)', sheet_url)
        if match:
            try:
                print(f"{Color.CYAN}[*] Fetching data...{Color.RESET}")
                res = requests.get(f"https://docs.google.com/spreadsheets/d/{match.group(1)}/export?format=csv")
                res.raise_for_status()
                if "<html" in res.text.lower(): print(f"\n{Color.RED}{Color.BOLD}[X] ERROR: Sheet is Private!{Color.RESET}"); time.sleep(2)
                else:
                    routers_list = list(csv.reader(res.text.strip().split('\n')))
                    start_winbox_automation(routers_list)
                    break
            except Exception as e:
                print(f"\n{Color.RED}{Color.BOLD}[X] ERROR: {e}{Color.RESET}"); time.sleep(2)
        else:
            print(f"\n{Color.RED}{Color.BOLD}[X] Invalid link!{Color.RESET}"); time.sleep(2)

    elif choice == '0':
        print(f"\n\n{Color.GREEN}{Color.BOLD}[*] Exiting Automation. Have a great day!{Color.RESET}")
        sys.exit()