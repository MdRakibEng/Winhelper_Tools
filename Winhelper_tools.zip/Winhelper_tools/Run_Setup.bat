@echo off
title Mikrotik Winbox Auto Setup
color 0b

:: ==========================================
:: 0. AUTO-REQUEST ADMINISTRATOR PRIVILEGES
:: ==========================================
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo [*] Requesting Administrator Privileges...
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    exit /B
)
if exist "%temp%\getadmin.vbs" ( del "%temp%\getadmin.vbs" )
pushd "%CD%"
CD /D "%~dp0"

echo ===================================================
echo         Mikrotik Winbox Auto Setup
echo ===================================================
echo.

:: 1. Check Python using py launcher or python
set "PYTHON_CMD="
py -0 >nul 2>&1
if %errorlevel% equ 0 (
    set "PYTHON_CMD=py"
    goto check_deps
)

python --version >nul 2>&1
if %errorlevel% equ 0 (
    set "PYTHON_CMD=python"
    goto check_deps
)

echo [*] Python not detected. Installing latest version via Winget...
winget install Python.Python.3.12 --source winget --silent --accept-package-agreements --accept-source-agreements

echo [*] Refreshing environment variables...
for /f "delims=" %%a in ('powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')"') do set "PATH=%%a"

set "PYTHON_CMD=py"

:check_deps
:: 2. Smart Check for Dependencies
%PYTHON_CMD% -c "import pyautogui, requests, keyboard" >nul 2>&1
if %errorlevel% equ 0 goto run_script

echo.
echo [*] Installing required libraries (pyautogui, requests, keyboard)...
%PYTHON_CMD% -m pip install --upgrade pip
%PYTHON_CMD% -m pip install pyautogui requests keyboard --no-warn-script-location
echo [SUCCESS] Dependencies installed!

:run_script
echo.
echo [*] Launching the interactive menu...
timeout /t 1 >nul

:: 3. Clear screen and run the main Python automation script
cls
%PYTHON_CMD% auto.py

echo.
echo [*] Script execution finished.
pause